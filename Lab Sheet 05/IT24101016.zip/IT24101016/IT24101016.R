getwd()
setwd("C:\\Users\\IT24101016\\Desktop\\IT24101016")

#Exercise
#1)
Delievery_Times<-read.table("Exercise - Lab 05.txt", header=TRUE, sep =",")

#2)
names(Delievery_Times) <- c("Times")
histogram <- hist(main = "Histogram for Delievery Times",Delievery_Times$Time,
                  breaks = seq(20,70,length=10),right=FALSE)

#4)
breaks <- round(histogram$breaks)
freq <- histogram$counts
mids <- histogram$mids

classes <- c()
for(i in 1:(length(breaks)-1)){
  classes[i] <- paste0("[",breaks[i],",", breaks[i+1],")")
}

cum.freq <- cumsum(freq)
new <- c()
for(i in 1:length(breaks)){
  if(i==1){
    new[i] = 0
  } else{
    new[i] = cum.freq[i-1]
  }
}
plot(breaks,new,type = 'l',main = "Cumalative Frequency Polygon for Delivery Times",
     xlab = "Delivery Time",ylab = "Cumulative Frequency",ylim = c(0,max(cum.freq)))

